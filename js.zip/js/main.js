// let year=document.getElementById('year');

// year.innerHTML=new Date().getFullYear();
$(document).ready(function(){


// let array=[{pic:'btn-pic7',id:20}
//     ,{pic:'btn-pic1',id:21}
//     ,{pic:'#child9',id:22}
//     ,{pic:'#child10',id:23}
//     ,{pic:'btn-pic6',id:24}]
// function searchPic(){
//     let picId=document.getElementById('h-id').value;
//     console.log(picId)
//     let id=array.findIndex(o =>o.id===picId);
//     if(id<0){
//         return 'No such house with this id Exists';
//     }
//     else if(picId===23){
//         $('#child10').show();
//     }
// }
})
console.log('check')